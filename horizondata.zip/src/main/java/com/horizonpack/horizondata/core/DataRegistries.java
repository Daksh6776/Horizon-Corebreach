package com.horizonpack.horizondata.core;

import com.horizonpack.horizondata.blockentities.*;
import com.horizonpack.horizondata.blocks.HorizonDataBlocks;
import com.horizonpack.horizondata.data.WorkshopType;
import com.horizonpack.horizondata.inventory.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;

public class DataRegistries {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(BuiltInRegistries.BLOCK, HorizonData.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(BuiltInRegistries.ITEM, HorizonData.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, HorizonData.MODID);
    public static final DeferredRegister<MenuType<?>> MENU_TYPES = DeferredRegister.create(BuiltInRegistries.MENU, HorizonData.MODID);
    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(BuiltInRegistries.RECIPE_TYPE, HorizonData.MODID);
    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = DeferredRegister.create(BuiltInRegistries.RECIPE_SERIALIZER, HorizonData.MODID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HorizonData.MODID);

    // --- Block Entities ---
    private static <T extends BlockEntityType<?>> DeferredHolder<BlockEntityType<?>, T> registerBE(String name, Supplier<T> supplier) {
        return BLOCK_ENTITIES.register(name, supplier);
    }

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<BloomeryBlockEntity>> BLOOMERY_BE =
            registerBE("bloomery", () -> BlockEntityType.Builder.of(BloomeryBlockEntity::new, HorizonDataBlocks.BLOOMERY.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CrucibleBlockEntity>> CRUCIBLE_BE =
            registerBE("crucible", () -> BlockEntityType.Builder.of(CrucibleBlockEntity::new, HorizonDataBlocks.CRUCIBLE.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ForgeBlockEntity>> FORGE_BE =
            registerBE("forge", () -> BlockEntityType.Builder.of(ForgeBlockEntity::new, HorizonDataBlocks.FORGE.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GrindstoneBlockEntity>> GRINDSTONE_BE =
            registerBE("grindstone", () -> BlockEntityType.Builder.of(GrindstoneBlockEntity::new, HorizonDataBlocks.GRINDSTONE.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AlchemyLabBlockEntity>> ALCHEMY_LAB_BE =
            registerBE("alchemy_lab", () -> BlockEntityType.Builder.of(AlchemyLabBlockEntity::new, HorizonDataBlocks.ALCHEMY_LAB.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<AnvilBlockEntity>> ANVIL_BE =
            registerBE("anvil", () -> BlockEntityType.Builder.of(AnvilBlockEntity::new, HorizonDataBlocks.ANVIL.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CarpentryBenchBlockEntity>> CARPENTRY_BENCH_BE =
            registerBE("carpentry_bench", () -> BlockEntityType.Builder.of(CarpentryBenchBlockEntity::new, HorizonDataBlocks.CARPENTRY_BENCH.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<KitchenBlockEntity>> KITCHEN_BE =
            registerBE("kitchen", () -> BlockEntityType.Builder.of(KitchenBlockEntity::new, HorizonDataBlocks.KITCHEN.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<LoomBlockEntity>> LOOM_BE =
            registerBE("loom", () -> BlockEntityType.Builder.of(LoomBlockEntity::new, HorizonDataBlocks.LOOM.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PotteryWheelBlockEntity>> POTTERY_WHEEL_BE =
            registerBE("pottery_wheel", () -> BlockEntityType.Builder.of(PotteryWheelBlockEntity::new, HorizonDataBlocks.POTTERY_WHEEL.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<TanneryBlockEntity>> TANNERY_BE =
            registerBE("tannery", () -> BlockEntityType.Builder.of(TanneryBlockEntity::new, HorizonDataBlocks.TANNERY.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<WorkbenchBlockEntity>> WORKBENCH_BE =
            registerBE("workbench", () -> BlockEntityType.Builder.of(WorkbenchBlockEntity::new, HorizonDataBlocks.WORKBENCH.get()).build((com.mojang.datafixers.types.Type<?>) null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<OilDepositBlockEntity>> DEPOSIT_BE =
            registerBE("deposit", () -> BlockEntityType.Builder.of(OilDepositBlockEntity::new, HorizonDataBlocks.NATURAL_GAS_POCKET.get(), HorizonDataBlocks.NATURAL_GAS_POCKET.get()).build((com.mojang.datafixers.types.Type<?>) null));

    // --- Menus ---
    public static final Supplier<MenuType<AnvilMenu>> ANVIL_MENU = MENU_TYPES.register("anvil", () -> new MenuType<>(AnvilMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<AlchemyLabMenu>> ALCHEMY_LAB_MENU = MENU_TYPES.register("alchemy_lab", () -> new MenuType<>(AlchemyLabMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<LoomMenu>> LOOM_MENU = MENU_TYPES.register("loom", () -> new MenuType<>(LoomMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<TanneryMenu>> TANNERY_MENU = MENU_TYPES.register("tannery", () -> new MenuType<>(TanneryMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<WorkbenchMenu>> WORKBENCH_MENU = MENU_TYPES.register("workbench", () -> new MenuType<>(WorkbenchMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<PotteryWheelMenu>> POTTERY_WHEEL_MENU = MENU_TYPES.register("pottery_wheel", () -> new MenuType<>(PotteryWheelMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<KitchenMenu>> KITCHEN_MENU = MENU_TYPES.register("kitchen", () -> new MenuType<>(KitchenMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<CarpentryBenchMenu>> CARPENTRY_BENCH_MENU = MENU_TYPES.register("carpentry_bench", () -> new MenuType<>(CarpentryBenchMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<GrindstoneMenu>> GRINDSTONE_MENU = MENU_TYPES.register("grindstone", () -> new MenuType<>(GrindstoneMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<ForgeMenu>> FORGE_MENU = MENU_TYPES.register("forge", () -> new MenuType<>(ForgeMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<BloomeryMenu>> BLOOMERY_MENU = MENU_TYPES.register("bloomery", () -> new MenuType<>(BloomeryMenu::new, FeatureFlags.DEFAULT_FLAGS));
    public static final Supplier<MenuType<CrucibleMenu>> CRUCIBLE_MENU = MENU_TYPES.register("crucible", () -> new MenuType<>(CrucibleMenu::new, FeatureFlags.DEFAULT_FLAGS));

    // --- Recipes ---
    public static final Map<WorkshopType, Supplier<RecipeType<?>>> WORKSHOP_RECIPE_TYPES = new EnumMap<>(WorkshopType.class);

    static {
        for (WorkshopType type : WorkshopType.values()) {
            // Guard against null IDs to prevent "null_recipe" duplicate registration
            if (type.id() != null) {
                WORKSHOP_RECIPE_TYPES.put(type, RECIPE_TYPES.register(type.id() + "_recipe", () -> new RecipeType<>() {
                    @Override
                    public String toString() {
                        return HorizonData.MODID + ":" + type.id();
                    }
                }));
            }
        }
    }
}