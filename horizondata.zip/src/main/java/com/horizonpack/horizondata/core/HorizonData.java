package com.horizonpack.horizondata.core;

import com.horizonpack.horizondata.blocks.HorizonDataBlocks;
import com.horizonpack.horizondata.blocks.ores.OreBlockRegistry;
import com.horizonpack.horizondata.items.HorizonDataItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

@Mod(HorizonData.MODID)
public class HorizonData {
    public static final String MODID = "horizondata";

    // This should be your ONLY public constructor
    public HorizonData(IEventBus modEventBus) {
        // 1. Register everything
        DataRegistries.BLOCKS.register(modEventBus);
        DataRegistries.ITEMS.register(modEventBus);
        DataRegistries.BLOCK_ENTITIES.register(modEventBus);
        DataRegistries.MENU_TYPES.register(modEventBus);
        DataRegistries.RECIPE_TYPES.register(modEventBus);
        DataRegistries.RECIPE_SERIALIZERS.register(modEventBus);
        DataRegistries.CREATIVE_TABS.register(modEventBus);

        // 2. Wake up the Ore Registry (Do NOT put this in a second constructor)
        com.horizonpack.horizondata.blocks.ores.OreBlockRegistry.init();

        // 3. Register the commonSetup method
        modEventBus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        // ... any setup logic ...
    }
}